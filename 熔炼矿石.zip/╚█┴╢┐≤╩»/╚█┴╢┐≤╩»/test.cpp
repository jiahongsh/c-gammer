#include<iostream>

using namespace std;
const int MAX_N = 1e4 + 1;
int N;
int A[MAX_N], B[MAX_N];

bool check_min(int x) {
	for (int i = 1; i <=N; i++) 
		if (A[i] / x > B[i])return false;
	
	return true;
}

bool check_max(int x) {
	for (int i = 1; i <= x; i++) {
		if (A[i] / x < B[i])return false;
	}
	return true;
}
int main() {
	cin >> N;
	for (int i = 1; i <= N; i++)cin >> A[i] >> B[i];

	int l = 1;
	int r = 1000000000;
	int V_min=100000;
	while (l <= r) {
		int mid = l + (r - l) / 2;
		if (check_min(mid) == true) {
			V_min = mid;
			r = mid-1 ;
		}
		else l = mid + 1;
	}
	l = 1;
	r = 1000000000;
	int V_max=0;
	while (l <= r) {
		int  mid = l + (r - l) / 2;
		if (check_max(mid) == true) {
			V_max = mid;
			l = mid + 1;
		}
		else r = mid-1 ;
	}


	cout << V_min << ' ' << V_max ;
	return 0;
}


